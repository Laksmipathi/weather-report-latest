package com.weather.model;

import lombok.Data;

@Data
public class Coord {
    private double lon;
    private double lat;

}
