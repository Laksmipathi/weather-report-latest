package com.weather.service;

import com.weather.model.WeatherReportResponse;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
public class WeatherReportServiceTest {

    @Mock
    WeatherReportService weatherReportService;
    @Mock
    RestTemplate restTemplate;

    @Test
    public void testGetReport(){
        WeatherReportResponse mockResponse = new WeatherReportResponse();
        mockResponse.setName("blr");
        ResponseEntity<WeatherReportResponse> responseEntity = new ResponseEntity<>(mockResponse, HttpStatus.OK);
        Mockito.when(restTemplate.exchange(Mockito.anyString(), Mockito.eq(HttpMethod.GET), Mockito.any(), Mockito.eq(WeatherReportResponse.class), Mockito.anyDouble(), Mockito.anyDouble(), Mockito.anyString()))
                .thenReturn(responseEntity);
        assertNull(weatherReportService.getWeatherReport(44.34, 10.99));
    }
}
