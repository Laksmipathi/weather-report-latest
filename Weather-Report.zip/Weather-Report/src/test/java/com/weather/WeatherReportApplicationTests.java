package com.weather;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WeatherReportApplicationTests {

	@Test
	void contextLoads() {
	}

}
